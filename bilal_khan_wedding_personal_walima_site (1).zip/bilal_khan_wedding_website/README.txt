BILAL KHAN & FALAK I ZHAR — PERSONAL WALIMA WEBSITE

Changes:
- About Me changed to Our Story.
- Kind Words / Testimonials section removed.
- Destination wedding wording and UAE references changed to Kanpur, India.
- Services reframed as celebration highlights.
- Portfolio heading reframed as Wedding Gallery.

To publish the changes to your existing Netlify website:
1. Extract this ZIP.
2. Open Netlify and select the existing site.
3. Open the Deploys tab.
4. Drag the extracted folder's contents (index.html, style.css, script.js) into the manual deploy area if shown, or use the site's manual deploy workflow.
5. Wait for deployment to finish, then refresh the live website.
Note: Replace sample gallery images with your own wedding photos when available.
